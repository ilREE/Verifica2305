
/**
 * Aggiungi qui una descrizione della classe TabellaVuota
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class TabellaVuota extends Exception
{
}
