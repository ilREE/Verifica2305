
/**
 * Aggiungi qui una descrizione dell'interfaccia Costanti
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */

public interface Costanti
{
    static final int MAXL=10;
}
