
/**
 * Aggiungi qui una descrizione della classe TabellaPiena
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class TabellaPiena extends Exception
{
    
}
