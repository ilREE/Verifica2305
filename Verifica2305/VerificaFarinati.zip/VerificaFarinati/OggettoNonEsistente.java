
/**
 * Aggiungi qui una descrizione della classe OggettoNonEsistente
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class OggettoNonEsistente extends Exception
{
    
}
