public class Oggetto implements Cloneable
{
    private String nome;
    private double prezzo;
    private int quantita;

    public Oggetto()
    {
        setNome("");
        setPrezzo(0);
        setQuantita(0);
    }
    
    public Oggetto(String nome, double prezzo, int quantita){
        setNome(nome);
        setPrezzo(prezzo);
        setQuantita(quantita);
    }
    
    public void setNome(String nome){this.nome=nome;}
    
    public String getNome(){return nome;}
    
    public void setPrezzo (double prezzo){this.prezzo=prezzo;}
    
    public double getPrezzo (){return prezzo;}
    
    public void setQuantita(int quantita){this.quantita=quantita;}
    
    public int getQuantita(){return quantita;}
    
    public String toString(){
        return("nome: "+getNome()+" prezzo: "+getPrezzo()+" quantita: "+getQuantita());
    }
    
    public Oggetto clone ()throws CloneNotSupportedException{
        return(Oggetto)super.clone();
    }
}
