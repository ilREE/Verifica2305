import java.util.*;

public class Inventario implements Costanti
{
    private HashMap<String,Oggetto>memo;
    
    public Inventario (){
        memo=new HashMap<String,Oggetto>(MAXL);
    }
    
    public void addProdotto (Oggetto o)throws TabellaPiena, OggettoEsistente, CloneNotSupportedException{
        if(memo.size() >= MAXL){
            throw new TabellaPiena();
        }
        if(memo.containsKey(o.getNome())){
            throw new OggettoEsistente();
        }
        memo.put(o.getNome(), o);
    }
    
    public void removeProdotto (Oggetto o)throws TabellaVuota, OggettoNonEsistente, CloneNotSupportedException{
        if(memo.size() == 0){
            throw new TabellaVuota();
        }
        if(!memo.containsKey(o.getNome())){
            throw new OggettoNonEsistente();
        }
        memo.remove(o.getNome());
    }
    
    public String elenco(){
        String s ="";
        for(Oggetto oggetto : memo.values()){
            s+=oggetto.toString()+"\n";
        }return s;
    }
    
        public void removeProdottoNome (String nome)throws TabellaVuota, OggettoNonEsistente, CloneNotSupportedException{
        if(memo.size() == 0){
            throw new TabellaVuota();
        }
        if(!memo.containsKey(nome)){
            throw new OggettoNonEsistente();
        }
        memo.remove(nome);
    }
    
    public float costoTotale () {
        float totale  = 0;
        for(Oggetto oggetto : memo.values()){
            totale += oggetto.getPrezzo()*oggetto.getQuantita();
        }
        return totale;
    }
    
    public Oggetto costoMaggiore() throws CloneNotSupportedException {
        Oggetto t = new Oggetto ();
        for(Oggetto oggetto : memo.values()){
            if(t.getPrezzo() < oggetto.getPrezzo()){
                t = oggetto.clone(); 
            }
        }
        return t;
    }
    
    public Oggetto quantitaMaggiore() throws CloneNotSupportedException {
        Oggetto t2 = new Oggetto();
        for(Oggetto oggetto : memo.values()){
            if(t2.getQuantita() < oggetto.getQuantita()){
                t2 = oggetto.clone();
            }
        }
        return t2;
    }
}
