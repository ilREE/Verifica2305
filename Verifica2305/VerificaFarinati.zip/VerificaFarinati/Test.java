
/**
 1.Che cos'é una HashMap?
   Rappresenta una struttura dati che memorizza una collezione di 
   coppie chiave-valore, in cui ogni chiave è univoca. 
   Essa fornisce un modo efficiente per l'inserimento, 
   l'accesso e la rimozione degli elementi sulla base delle chiavi.
   
2.Le HashMap vengono utilizzate per diverse ragioni:
  - Ricerca
  - Inserimento e rimozione
  - Adattabilità alla dimensione dei dati, non è necessario utilizzare una dimensione fissa.
 */
public class Test
{
    public static void main(String[] args)throws TabellaPiena, OggettoNonEsistente, OggettoEsistente, TabellaVuota, CloneNotSupportedException{
        Oggetto o1 = new Oggetto ("Scotch",1.20, 50);
        Oggetto o2 = new Oggetto ("Penna" , 0.50, 80);
        Oggetto o3 = new Oggetto ("Matita", 0.40, 30);
        
        Inventario i1 = new Inventario ();
        
        i1.addProdotto(o1);
        i1.addProdotto(o2);
        i1.addProdotto(o3);
        
        System.out.println(i1.elenco());
        /*
        i1.removeProdottoNome("Penna");
        
        System.out.println(i1.elenco());
        
        i1.removeProdotto(o1);
        
        System.out.println(i1.elenco());*/
        
        System.out.println("Il costo totale e "+i1.costoTotale());
        
        System.out.println("Oggetto piu costoso -> "+i1.costoMaggiore().toString());
        
        System.out.println("Oggetto con maggiore quantita -> "+i1.quantitaMaggiore().toString());
    }
}
