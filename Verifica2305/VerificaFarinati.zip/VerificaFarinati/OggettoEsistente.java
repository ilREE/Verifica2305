
/**
 * Aggiungi qui una descrizione della classe OggettoEsistente
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class OggettoEsistente extends Exception
{
    
}
